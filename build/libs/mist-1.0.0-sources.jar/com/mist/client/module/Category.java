package com.mist.client.module;

public enum Category {
        COMBAT("Combat"),
        RENDER("Render"),
        HUD("HUD"),
        UTILITY("Utility");

        private final String displayName;

        Category(String displayName) {
                this.displayName = displayName;
        }

        public String getDisplayName() {
                return displayName;
        }
}
